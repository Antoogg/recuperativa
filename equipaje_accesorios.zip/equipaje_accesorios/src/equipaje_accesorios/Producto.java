/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package equipaje_accesorios;

/**
 *
 * @author carre
 */
public class Producto {
    private String cod, nom_pro, tipo;
    private double precio_uni;

    public Producto(String cod, String nom_pro, String tipo, double precio_uni) {
        this.cod = cod;
        this.nom_pro = nom_pro;
        this.tipo = tipo;
        this.precio_uni = precio_uni;
    }

    public Producto() {
    }

    public String getCod() {
        return cod;
    }

    public void setCod(String cod) {
        this.cod = cod;
    }

    public String getNom_pro() {
        return nom_pro;
    }

    public void setNom_pro(String nom_pro) {
        this.nom_pro = nom_pro;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public double getPrecio_uni() {
        return precio_uni;
    }

    public void setPrecio_uni(double precio_uni) {
        this.precio_uni = precio_uni;
    }
    
    
}
