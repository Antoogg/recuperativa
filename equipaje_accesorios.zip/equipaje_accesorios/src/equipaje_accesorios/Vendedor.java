/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package equipaje_accesorios;

/**
 *
 * @author carre
 */
import java.time.LocalDate;
public class Vendedor {
    private String nom_ven, rut_ven;
    private int nro_vendedor;
    private LocalDate fdi;
    private Zona zona_geo;

    public Vendedor(String nom_ven, String rut_ven, int nro_vendedor, LocalDate fdi, Zona zona_geo) {
        this.nom_ven = nom_ven;
        this.rut_ven = rut_ven;
        this.nro_vendedor = nro_vendedor;
        this.fdi = fdi;
        this.zona_geo = zona_geo;
    }

    public Vendedor() {
    }

    public String getNom_ven() {
        return nom_ven;
    }

    public void setNom_ven(String nom_ven) {
        this.nom_ven = nom_ven;
    }
    
    public String getRut_ven() {
        return rut_ven;
    }

    public void setRut_ven(String rut_ven) {
        this.rut_ven = rut_ven;
    }

    public int getNro_vendedor() {
        return nro_vendedor;
    }

    public void setNro_vendedor(int nro_vendedor) {
        this.nro_vendedor = nro_vendedor;
    }

    public LocalDate getFdi() {
        return fdi;
    }

    public void setFdi(LocalDate fdi) {
        this.fdi = fdi;
    }

    public Zona getZona_geo() {
        return zona_geo;
    }

    public void setZona_geo(Zona zona_geo) {
        this.zona_geo = zona_geo;
    }
    
    public void validandoVen(){
        boolean nombreValido= (nom_ven != null && !nom_ven.trim().isEmpty());

        if (!nombreValido) {
            System.out.println("El nombre no puede estar vacío.");
            System.exit(0);
        }

        System.out.println("Nombre válido.");
    }
}
