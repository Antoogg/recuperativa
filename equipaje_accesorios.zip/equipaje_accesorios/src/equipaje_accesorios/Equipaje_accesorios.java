/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package equipaje_accesorios;

/**
 *
 * @author carre
 */
import java.util.Scanner;
import java.time.LocalDate;
public class Equipaje_accesorios {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner sc=new Scanner(System.in);
        Cliente cli=new Cliente();
        Vendedor ven=new Vendedor();
        Producto pro=new Producto();
        Pedido ped=new Pedido();
        
        while (true) {
            System.out.println("\n=== SISTEMA DE PEDIDOS DE EQUIPAJE Y ACCESORIOS DE VIAJE ===");
            System.out.println("1. Ingresar Cliente.");
            System.out.println("2. Ingresar Vendedor.");
            System.out.println("3. Ingresar Producto.");
            System.out.println("4. Generar Pedido.");
            System.out.println("5. Salir.");
            System.out.print("\nSeleccione una opción: ");
            int op= sc.nextInt();
            sc.nextLine(); 

            switch (op) {
                case 1:
                    System.out.println("--- INGRESO DE CLIENTE ---");
                    System.out.print("RUT: ");
                    String rutC = sc.nextLine();
                    cli.setRut(rutC);
                    System.out.print("Nombre: ");
                    String nombreC = sc.nextLine();
                    cli.setNom(nombreC);
                    cli.validandoCli1();
                    System.out.print("Edad: ");
                    int edad = sc.nextInt();
                    sc.nextLine();
                    cli.setEdad(edad);
                    cli.validandoCli2();
                    System.out.print("Fecha nacimiento (AAAA-MM-DD): ");
                    String fdnC = sc.nextLine();
                    LocalDate naci_cli= LocalDate.parse(fdnC);
                    cli.setFdn(naci_cli);
                    System.out.println("Cliente registrado con exito. ");
                    break;
                case 2:
                    System.out.println("--- INGRESO DE VENDEDOR ---");
                    System.out.print("RUT: ");
                    String rutV = sc.nextLine();
                    ven.setRut_ven(rutV);
                    System.out.print("Nombre: ");
                    String nombreV = sc.nextLine();
                    ven.setNom_ven(nombreV);
                    ven.validandoVen();
                    System.out.print("Fecha ingreso (AAAA-MM-DD): ");
                    String fdiV = sc.nextLine();
                    LocalDate ingreso=LocalDate.parse(fdiV);
                    LocalDate hoy=LocalDate.now();
                    if (ingreso.isAfter(hoy)){
                        System.out.println("Fecha invalida. La fecha ingresada es posterior a hoy. ");
                        break;
                    } else{
                        System.out.println("Fecha ingresada valida. ");
                    }
                    ven.setFdi(ingreso);
                    System.out.println("Ingreso de vendedor exitosa. ");
                    break;
                case 3:
                    System.out.println("--- INGRESO DE PRODUCTO ---");
                    System.out.print("Código: ");
                    String codigo = sc.nextLine();
                    pro.setCod(codigo);
                    System.out.print("Nombre: ");
                    String nombreP = sc.nextLine();
                    pro.setNom_pro(nombreP);
                    ped.setProducto(pro);
                    System.out.print("Tipo (Maleta/Mochila/Bolso): ");
                    String tipo = sc.nextLine();
                    String ingresoP=tipo.toLowerCase();
                    if (ingresoP.equals("maleta") || ingresoP.equals("mochila") || ingresoP.equals("bolso")){
                        System.out.println("Producto valido. ");
                    } else {
                        System.out.println("Producto no valido. ");
                        break;
                    }
                    pro.setTipo(ingresoP);
                    System.out.print("Precio unitario: ");
                    double precio = sc.nextDouble();
                    sc.nextLine();
                    pro.setPrecio_uni(precio);
                    System.out.println("Producto registrado con exito. ");
                    break;
                case 4:
                    if (cli.getNom()!= null && ven.getNom_ven()!= null && pro.getNom_pro()!= null) {
                        System.out.print("Cantidad: ");
                        int cantidad = sc.nextInt();
                        sc.nextLine();
                        ped.setCantidad(cantidad);
                        System.out.print("Fecha pedido (AAAA-MM-DD): ");
                        String fecha = sc.nextLine();
                        ped.setFecha(fecha);
                    } else {
                        System.out.println("Debe ingresar cliente, vendedor y producto antes de generar pedido.");
                    }
                    break;
                case 5:
                    System.out.println("Saliendo...");
                    return;
                default:
                    System.out.println("Opción inválida.");
            }
        }
        
    }
}
