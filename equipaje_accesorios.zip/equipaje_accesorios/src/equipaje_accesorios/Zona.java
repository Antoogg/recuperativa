/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package equipaje_accesorios;

/**
 *
 * @author carre
 */
public class Zona {
    private String nom_z, ciudad_prin;
    private int num_zona;

    public Zona(String nom_z, String ciudad_prin, int num_zona) {
        this.nom_z = nom_z;
        this.ciudad_prin = ciudad_prin;
        this.num_zona = num_zona;
    }

    public Zona() {
    }

    public String getNom_z() {
        return nom_z;
    }

    public void setNom_z(String nom_z) {
        this.nom_z = nom_z;
    }

    public String getCiudad_prin() {
        return ciudad_prin;
    }

    public void setCiudad_prin(String ciudad_prin) {
        this.ciudad_prin = ciudad_prin;
    }

    public int getNum_zona() {
        return num_zona;
    }

    public void setNum_zona(int num_zona) {
        this.num_zona = num_zona;
    }
    
}
