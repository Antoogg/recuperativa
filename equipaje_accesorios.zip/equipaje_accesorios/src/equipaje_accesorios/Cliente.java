/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package equipaje_accesorios;

/**
 *
 * @author carre
 */
import java.time.LocalDate;
public class Cliente {
    private String nom, rut;
    private int edad;
    private LocalDate fdn;

    public Cliente(String nom, String rut, int edad, LocalDate fdn) {
        this.nom = nom;
        this.rut = rut;
        this.edad = edad;
        this.fdn = fdn;
    }

    public Cliente() {
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public String getRut() {
        return rut;
    }

    public void setRut(String rut) {
        this.rut = rut;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    public LocalDate getFdn() {
        return fdn;
    }

    public void setFdn(LocalDate fdn) {
        this.fdn = fdn;
    }
    
    public void validandoCli1(){
        boolean nombreValido= (nom != null && !nom.trim().isEmpty());
        
        if (!nombreValido) {
            System.out.println("El nombre no puede estar vacío.");
            System.exit(0);
        }

        System.out.println("Nombre válido.");
    }
    
        public void validandoCli2(){
        boolean edadValida= (edad >= 18 && edad < 80);
        
        if (!edadValida) {
            System.out.println("Su edad no es válida.");
            System.exit(0);
            
        }

        System.out.println("Edad válida.");
    }
}
