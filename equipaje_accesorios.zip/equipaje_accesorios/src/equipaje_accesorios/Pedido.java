/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package equipaje_accesorios;

/**
 *
 * @author carre
 */
public class Pedido {
    private Cliente cliente;
    private Producto producto;
    private Vendedor vendedor;
    private double cantidad;
    private String fecha;

    public Pedido(Cliente cliente, Producto producto, Vendedor vendedor, double cantidad, String fecha) {
        this.cliente = cliente;
        this.producto = producto;
        this.vendedor = vendedor;
        this.cantidad = cantidad;
        this.fecha = fecha;
    }

    public Pedido() {
    }

    public Cliente getCliente() {
        return cliente;
    }

    public void setCliente(Cliente cliente) {
        this.cliente = cliente;
    }

    public Producto getProducto() {
        return producto;
    }

    public void setProducto(Producto producto) {
        this.producto = producto;
    }

    public Vendedor getVendedor() {
        return vendedor;
    }

    public void setVendedor(Vendedor vendedor) {
        this.vendedor = vendedor;
    }

    public double getCantidad() {
        return cantidad;
    }

    public void setCantidad(double cantidad) {
        this.cantidad = cantidad;
    }

    public String getFecha() {
        return fecha;
    }

    public void setFecha(String fecha) {
        this.fecha = fecha;
    }
    public void calcularTotalBruto() {
        double total = cantidad * producto.getPrecio_uni();
        if (cliente.getEdad()> 65) {
            total*=0.5;
        }
    }

    public void calcularDescuento(double totalBruto) {
        double descuento = 0;

        if (totalBruto>120000) {
            descuento=totalBruto*0.25;
        } else if (totalBruto>60000) {
            descuento=totalBruto*0.15;
        }
    }

    public void estadoPedido() {
        boolean edadValida= cliente.getEdad()>=18 && cliente.getEdad()<80;
        boolean nombreCliValido= cliente.getNom()!=null && !cliente.getNom().trim().isEmpty();
        boolean nombreVenValido= vendedor.getNom_ven() !=null && !vendedor.getNom_ven().trim().isEmpty();
        if (edadValida && nombreCliValido && nombreVenValido) {
            System.out.println("Confirmado");
        } else {
            System.out.println("Pendiente");
        }
    }
}
